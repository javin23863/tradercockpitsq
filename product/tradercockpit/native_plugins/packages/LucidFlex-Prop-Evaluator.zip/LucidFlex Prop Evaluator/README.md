# LucidFlex Prop Evaluator

A StrategyQuantX Results-tab plugin that answers one question:

> **"Would this strategy pass a LucidFlex futures evaluation — or survive as a funded account?"**

It replays your backtest's trades through LucidFlex's actual rule set — the **end-of-day trailing Max Loss Limit** (with the lock at initial + $100), the **profit target**, and the **50% consistency rule** — all in real dollars, and gives you a PASS / ALMOST / FAIL verdict, the rule-by-rule breakdown, and a Monte-Carlo pass probability.

---

## 1. Installation

1. Copy the **`LucidFlex Prop Evaluator`** folder into your SQX plugins directory:
   ```
   <SQX-install>/user/extend/ResultsPlugins/LucidFlex Prop Evaluator/
   ```
   Keep the folder intact — it must contain `index.html`, `vue.global.prod.js`, and the `locales/` folder.
2. **Restart StrategyQuantX** (or click the **reload icon** in the Results tab) so SQX registers the new plugin.
3. Run or open any backtest, go to the **Results** tab, and select **LucidFlex Prop Evaluator** from the tab strip.

Requires SQX **Pro** (up to 3 custom plugins) or **Ultimate** (unlimited). Starter does not support custom plugins.

---

## 2. Controls

| Control | What it does |
|---|---|
| **Account Type** | **Evaluation** (profit target + 50% consistency must be met) or **Funded** (no target/consistency/DLL — you only need to survive the trailing drawdown; shows the 90% payout share). |
| **Account Size** | $25K / $50K / $100K / $150K. Each loads its real profit target, Max Loss Limit, trailing-lock point, and contract limits. |
| **Size Multiplier** | Scales every trade's P&L and contract count to simulate trading more or fewer contracts than the backtest used (1 = as-is, 2 = double, 0.5 = half). LucidFlex limits are fixed in dollars, so sizing changes the outcome. |

---

## 3. The rules this plugin checks

| Rule | Evaluation | Funded |
|---|---|---|
| **Profit Target** | Must reach +$1,250 / $3,000 / $6,000 / $9,000 (by tier) | — |
| **Max Loss Limit (EOD trailing)** | Drawdown line starts MLL below balance, trails the highest *end-of-day* close, and **locks at initial + $100**. Touching it = breach. | Same |
| **Consistency (50%)** | Largest single-day profit ÷ total profit must be ≤ 50% to upgrade | — |
| **Daily Loss Limit** | None — LucidFlex has no DLL | None |
| **Max Position Size** | Informational vs the tier's mini/micro limit | Same |

Breaches are tested against **worst-case intraday equity**, estimated from each trade's MAE — so a day that closes green but dipped hard mid-session can still fail.

---

## 4. What you get

- **Verdict card** — PASS (cleared all rules), ALMOST (target hit but consistency over 50%), or FAIL (drawdown breach or target never reached).
- **KPI strip** — net profit, days to target, consistency %, minimum MLL headroom, estimated 90% payout (funded), and the breached rule.
- **Rule cards** — every rule with its current value vs. the limit and a plain-language tooltip.
- **Charts** — equity vs. trailing drawdown, daily P&L, headroom above the MLL, and a consistency / profit-distribution view.
- **Sliding-window Monte Carlo** (Evaluation) — picks random start days from your history and replays forward to estimate your pass probability and how it tends to fail.

---

## 5. Important caveats

- **Closed-trade backtests don't capture true intraday execution.** Intraday lows are approximated from each trade's MAE (pessimistic-but-safe). Real fills, slippage, velocity logic, and fees will differ.
- **A backtest PASS is not a live PASS.** Treat the verdict as evidence, not certainty.
- **Day boundaries use US Eastern (ET), DST-aware**, to approximate the futures session/EOD reset. A different settlement hour shifts the daily buckets slightly.
- **The 50% consistency cushion is approximated.** Lucid's actual cushion is a per-day percentage of realized profit; this tool applies the 50% cap and notes the cushion.

---

## 6. Technical notes

- Tech: Vue 3 (local `vue.global.prod.js`, no CDN), Canvas charts, CSS-variable theming.
- Follows SQX `SET_THEME`; canvas redraws on theme change. Uses `GET_ORDERS` (Portfolio result).
- i18n: English + Czech ship by default. Add locales by dropping `<locale>.json` into `locales/`.
- All account specs live in the `ACCOUNTS` constant near the top of `index.html` — the single source of truth if Lucid changes its numbers.

---

*Built for traders evaluating SQX strategies against real LucidFlex prop-firm conditions. Not financial advice. See the disclaimer at the bottom of the plugin.*
