# Edge Decay Analyzer — SQX 144+ Plugin

Plugin para StrategyQuant X 144+ que analiza la **calidad del edge** de cada estrategia y mide cuánto degrada del In-Sample al Out-of-Sample.

## 🎯 Qué hace

Cuando clicas una estrategia en SQX, este plugin muestra:

1. **Score 0-100** de calidad del edge con grado A-F
2. **Desglose en 4 pilares**:
   - Rentabilidad
   - Consistencia
   - Gestión de Riesgo
   - Calidad de Entrada
3. **Comparativa IS vs OOS** de las métricas clave con decay y veredicto
4. **XS (calidad de entradas) año por año** — visualización clara
5. **Análisis de trades concurrentes** — detecta dependencia de Allow Duplicate Trades

## 📦 Instalación

### Paso 1: Copiar la carpeta

Copia la carpeta `Edge Decay Analyzer` completa (con su `index.html` y `locales/`) a:

```
[Tu instalación SQX]/user/extend/ResultsPlugins/Edge Decay Analyzer/
```

### Paso 2: Copiar Vue 3 desde otro plugin

El plugin necesita `vue.global.prod.js`. Cópialo desde un plugin oficial existente:

```
Origen:  user/extend/ResultsPlugins/Prop analytics/vue.global.prod.js
Destino: user/extend/ResultsPlugins/Edge Decay Analyzer/vue.global.prod.js
```

(O desde `Prop Monte Carlo` o `RobustnessScorecard` que también lo tienen)

### Paso 3: Reiniciar SQX

Cierra y abre SQX (o usa el botón de reload en la pestaña Results).

### Paso 4: Usar

1. Abre cualquier databank
2. Selecciona una estrategia
3. Ve a la pestaña Results
4. Selecciona "Edge Decay Analyzer"
5. Analiza el score y los pilares

## 🗑️ Desinstalación

Si no te gusta o quieres quitarlo:

1. Cierra SQX
2. Borra la carpeta `Edge Decay Analyzer/`
3. Abre SQX

Sin secuelas, sin residuos.

## 🛡️ Seguridad

- Solo lee datos vía PostMessage API
- No escribe nada
- No modifica estrategias ni databanks
- 100% local, sin red

## 📋 Idiomas soportados

- Inglés (en)
- Español (es)

El idioma se cambia automáticamente según la configuración de SQX.

## 🐛 Troubleshooting

### "No se ve el plugin en la lista"

- Verifica que la carpeta esté en `user/extend/ResultsPlugins/`
- Verifica que dentro hay un `index.html`
- Reinicia SQX completamente
- Verifica que tu licencia permite plugins (Pro: 3 máx, Ultimate: ilimitados)

### "Aparece la pantalla pero está vacía"

- Necesitas tener una estrategia seleccionada en el databank
- La estrategia debe tener periodo OOS configurado

### "Stats no cargan"

- Revisar la consola del navegador (F12 en SQX si está disponible)
- Verificar que `vue.global.prod.js` está en la carpeta del plugin

## 📚 Estructura

```
Edge Decay Analyzer/
├── index.html              ← código principal del plugin
├── vue.global.prod.js      ← Vue 3 (copiar desde otro plugin)
├── locales/
│   ├── en.json
│   └── es.json
└── README.md               ← este archivo
```
