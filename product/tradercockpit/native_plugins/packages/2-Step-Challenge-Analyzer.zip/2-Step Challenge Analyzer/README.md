# 2-Step Challenge Analyzer

A StrategyQuantX Results-tab plugin that answers one question:

> **"If I took this strategy (or portfolio) to a two-phase prop-firm evaluation, would it pass — and how often?"**

It replays the full two-phase rule set on your backtest — intraday equity (MAE-adjusted), CE(S)T day boundaries with DST, the daily-loss and max-loss limits (static **or** trailing floor), and the minimum-trading-days requirement — and gives you:

1. A **PASS / FAIL verdict** on the actual historical order sequence.
2. A **Monte Carlo pass probability** with a 95% confidence interval (how often you'd pass if you started on a different day).
3. A **per-tier expected-value table** so you can see which account size is worth buying.

---

## 1. Installation

1. The plugin folder is at:
   ```
   <SQX-install>/user/extend/ResultsPlugins/2-Step Challenge Analyzer/
   ```
2. **Restart StrategyQuantX** (or click the **reload icon** in the Results tab) so SQX picks up the plugin.
3. In any backtest, open the **Results** tab and select **2-Step Challenge Analyzer** from the tab strip.

Requires SQX **Pro** (3 custom plugins) or **Ultimate** (unlimited).

---

## 2. The challenge rules this plugin checks

| Rule | Phase 1 | Phase 2 | What it means |
|---|---|---|---|
| **Profit target** | +10% | +5% | The phase passes once cumulative return reaches the target **and** the minimum trading days are met |
| **Max daily loss** | −5% | −5% | No single CE(S)T day may lose more than 5% of the starting balance, measured intraday (MAE) |
| **Max loss (overall)** | −10% | −10% | Equity must never touch the floor (−10% from start in *Static* mode, or below the running peak −10% in *Trailing* mode) |
| **Min trading days** | 4 | 4 | At least 4 distinct days with a trade are required before a pass counts |
| **Trading period** | Unlimited | Unlimited | No time limit — failure only comes from breaching a loss limit |

The two phases run **sequentially**: Phase 2 begins on the trading day right after Phase 1 is cleared. Both limits are evaluated against worst-case intraday equity, not just the closing balance — so a strategy that closes green but dipped hard mid-day can still fail.

> All rule numbers live in the `CHALLENGE` constant near the top of `index.html`. If your firm uses different targets/limits, edit them there — it's the single source of truth.

---

## 3. The interface, top to bottom

### 3.1 Two tabs

- **Pass Analysis** — the verdict, KPIs, rule cards, phase breakdown, and the EV table.
- **Monte Carlo** — the simulation controls, pass probability, outcome breakdown, and charts.

### 3.2 Shared controls (top of both tabs)

| Control | What it does |
|---|---|
| **Strategy** | Only appears for a portfolio databank. Pick **Portfolio** to analyze the merged order stream of all strategies, or pick a single strategy (e.g. `EURUSD/H1`) to evaluate it on its own. Switching re-runs the whole analysis on that result. |
| **Sample** | **Full** (all data) · **In-Sample** (the data the strategy was built/optimized on — looks too good) · **Out-of-Sample** (unseen data — the honest test). A yellow warning appears for anything but OOS. |
| **Max-loss floor** | **Static** = fixed at −10% from the start. **Trailing** = the floor ratchets up with every new equity high, so giving back profit can fail you. Trailing is stricter. |

> Every control and metric has a **hover tooltip** with a plain-language definition and a worked example. If you're unsure what a number means, hover its label.

### 3.3 Verdict card

A big colored card:

- **PASS (green)** — the historical sequence cleared both phases without a breach. Detail line shows how many trading days each phase took.
- **FAIL (red)** — a limit was breached, or a target was never reached. Detail line names the phase and the reason (daily loss / max loss / target not reached).

Below the verdict sits the **Monte Carlo pass probability** with its 95% CI (when there's enough history).

### 3.4 KPI strip

| KPI | Reads |
|---|---|
| **Trading days** | Distinct CE(S)T days with a trade. More = a more reliable probability; under 60 is flagged. |
| **Net profit** | Total backtest return as % of the starting balance. |
| **Worst day (intraday)** | Deepest single-day loss from that day's open (MAE-based). Compare to the −5% daily limit. |
| **Max drawdown** | Largest peak-to-valley intraday equity drop. Compare to the −10% max-loss limit. |
| **Days to pass P1 / P2** | Trading days each phase needed on the historical run, or `—` if it didn't pass. |

### 3.5 Rule cards

One card per rule, with a colored left border (green = clear, red = breached, grey = informational), the current value vs. the limit, and a tooltip explaining it. This is the at-a-glance "where am I against each rule" view.

### 3.6 Phase-by-phase probability

Three numbers from the Monte Carlo:

- **Pass Phase 1** — probability of clearing +10% alone (usually the bottleneck).
- **Pass Phase 2 (given P1)** — probability of clearing +5% *after* P1 already passed.
- **Pass both phases** = P1 × (P2 given P1) — this equals the headline probability.

### 3.7 Expected value by account tier

Because risk is percent-based, the pass probability is identical across account sizes — only the **fee** and **reward** differ. The table shows, per tier:

- **Fee** and **Avg reward** — both **editable**; type your firm's real numbers.
- **Pass prob.** — the Monte Carlo number.
- **Expected value** = passProb × reward − (1 − passProb) × fee. (Fee assumed refunded on a pass, lost on a fail.)
- **ROI on fee** = EV ÷ fee.

The tier marked **BEST VALUE** is the firm's promoted one; **BEST EV** is the highest expected value given your inputs.

### 3.8 Monte Carlo tab

- **Iterations** (default 5,000) — more runs = a tighter confidence interval, slightly slower.
- **Avg block length** (default 5 ≈ one trading week) — how much loss-clustering the resampling preserves.
- **Run** — re-rolls the simulation.
- **Pass probability** big number + CI.
- **Outcome breakdown** — what share of attempts passed vs. failed by daily loss / max loss / target-not-reached.
- **Sample equity paths** chart — green = passing runs, red = failing, with the +target and −floor lines.
- **Days-to-pass histogram** — the distribution of how long passing attempts took.

---

## 4. How the Monte Carlo works (and why it's honest)

It uses a **stationary (block) bootstrap**: it stitches your daily-return series back together in random blocks (mean length ≈ the block-length setting), preserving streaks and loss-clustering that a naive shuffle would destroy — which matters because the daily- and max-loss rules are sequence-sensitive. Each synthetic run is put through the full two-phase engine; the share that pass is the probability.

- Needs **≥20 trading days** to run at all, and **≥60** before the result is treated as reliable (below that it's flagged *indicative only*).
- Path length is capped (~2× your history) so the "unlimited time" rule doesn't inflate the pass rate to 100%.
- The **95% confidence interval** (Wilson score) tells you how much to trust the point estimate — a wide band means too little history.

---

## 5. A practical workflow

1. If it's a portfolio, decide what you're testing — the **merged Portfolio** or a **single strategy** from the selector.
2. Switch **Sample** to **Out-of-Sample** for an honest read.
3. Pick the **floor mode** your firm actually uses (most 2-step challenges are static; choose Trailing if yours ratchets).
4. Read the **Verdict** first — but don't trust a deterministic PASS on its own.
5. Look at the **Monte Carlo pass probability**: above ~60% is a decent candidate; under ~40% means the historical PASS was mostly luck.
6. Check the **Outcome breakdown** to see *how* it tends to fail (daily loss → cut risk; max loss → watch give-back; target not reached → not profitable enough).
7. Enter your real fees/rewards in the **EV table** and buy the tier with the best EV/ROI.

---

## 6. Important caveats

- **Closed-trade backtests don't capture true intraday execution.** The plugin uses each trade's **MAE** to approximate worst-case intraday equity, assuming overlapping trades can hit their adverse excursion together (pessimistic-but-safe). Real broker execution, swaps, and slippage may differ.
- **A backtest PASS is not a live PASS guarantee.** Treat the verdict and probability as *evidence*, not certainty.
- **In-sample results are optimistic.** The probability is biased high on data the strategy was optimized on — prefer Out-of-Sample.
- **EV is a rough ranking.** Avg reward is a single point estimate; real payouts vary, are smaller for marginal passes, and you can pass yet never collect if the funded account later fails.
- **CE(S)T day boundary** is DST-aware and matches a Central-European server reset. A different broker reset hour shifts the daily windows slightly.

---

## 7. Technical notes

- Tech: Vue 3 (local `vue.global.prod.js`, no CDN), Canvas charts, CSS variables for theming.
- Theming follows SQX's `SET_THEME`; canvas charts redraw on theme change.
- i18n: English + Czech ship by default. Add more locales by dropping `<locale>.json` into `locales/`.
- Strategy selection uses the `dataItems` list from SQX's `STRATEGY_DATA` message; each entry is passed back verbatim as the `resultKey` for `GET_STATS` / `GET_ORDERS`.

---

*Built for traders evaluating SQX strategies against real two-phase prop-firm conditions. Not financial advice. See the disclaimer at the bottom of the plugin.*
