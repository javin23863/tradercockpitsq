# RunCompare — history storage backend (PowerShell, NO Python required).
#
# Stores each strategy's run history CENTRALLY, keyed by strategy name, in
# ".\history\<StrategyName>.runs.txt" next to this script (inside the plugin
# folder). This needs NO knowledge of where the user saved the .sqx — SQ's
# plugin API only gives the strategy NAME, never a file path — so central,
# name-keyed storage is the only approach that works no matter where the
# user keeps their strategies. Zero configuration.
#
# Endpoints: GET /ping, GET /load?fileName=..., POST /save?fileName=...
# Runs on built-in Windows PowerShell (5.1+). Launched by start-sq.bat.

$ErrorActionPreference = 'Stop'
$PORT = 8090
$HERE = Split-Path -Parent $MyInvocation.MyCommand.Definition
$HistoryDir = Join-Path $HERE 'history'

# ── storage (central, keyed by strategy name) ──────────────────────────────
function Safe-Name($name) {
    $stem = [regex]::Replace([string]$name, '\.sqx$', '', 'IgnoreCase')
    # strip characters not allowed in Windows filenames
    return ([regex]::Replace($stem, '[\\/:*?"<>|]', '_')).Trim()
}
function History-Path($fileName) {
    $safe = Safe-Name $fileName
    if ([string]::IsNullOrWhiteSpace($safe)) { return $null }
    return (Join-Path $HistoryDir ($safe + '.runs.txt'))
}
function Save-History($path, $stem, $history) {
    if (-not (Test-Path $HistoryDir)) { New-Item -ItemType Directory -Force -Path $HistoryDir | Out-Null }
    $obj = [ordered]@{
        _format   = 'RunCompare history'
        _strategy = $stem
        history   = @($history)   # force JSON array even for 0/1 items
    }
    $json = $obj | ConvertTo-Json -Depth 100
    [System.IO.File]::WriteAllText($path, $json, (New-Object System.Text.UTF8Encoding($false)))
}

# ── tiny HTTP over TcpListener (no admin / no URL ACL needed) ───────────────
function Send-Response($stream, $status, $statusText, $bodyString) {
    $bytes = if ($bodyString) { [System.Text.Encoding]::UTF8.GetBytes($bodyString) } else { [byte[]]@() }
    $head  = "HTTP/1.1 $status $statusText`r`n" +
             "Access-Control-Allow-Origin: *`r`n" +
             "Access-Control-Allow-Methods: GET, POST, OPTIONS`r`n" +
             "Access-Control-Allow-Headers: Content-Type`r`n" +
             "Content-Type: application/json; charset=utf-8`r`n" +
             "Content-Length: $($bytes.Length)`r`n" +
             "Connection: close`r`n`r`n"
    $hb = [System.Text.Encoding]::ASCII.GetBytes($head)
    $stream.Write($hb, 0, $hb.Length)
    if ($bytes.Length -gt 0) { $stream.Write($bytes, 0, $bytes.Length) }
    $stream.Flush()
}
function Send-Json($stream, $status, $obj) {
    $txt = switch ($status) { 200 {'OK'} 400 {'Bad Request'} 404 {'Not Found'} default {'OK'} }
    Send-Response $stream $status $txt ($obj | ConvertTo-Json -Depth 100 -Compress)
}
function Get-QueryParam($query, $name) {
    if (-not $query) { return '' }
    foreach ($pair in ($query -split '&')) {
        $kv = $pair -split '=', 2
        if ($kv[0] -eq $name -and $kv.Count -eq 2) { return [System.Uri]::UnescapeDataString($kv[1]) }
    }
    return ''
}

$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $PORT)
$listener.Start()
Write-Host "RunCompare storage (PowerShell) on http://localhost:$PORT/"
Write-Host "  history dir: $HistoryDir"

# Auto-shutdown: exit once StrategyQuant has closed, so no PowerShell lingers.
# SQ install root = 4 levels up (…\user\extend\ResultsPlugins\RunCompare → …\StrategyQuantX###).
$SqDir = $null
try { $SqDir = (Resolve-Path (Join-Path $HERE '..\..\..\..')).Path } catch { }
function Test-SqRunning {
    if (-not $SqDir) { return $true }
    foreach ($p in (Get-Process -ErrorAction SilentlyContinue)) {
        try { if ($p.Path -and $p.Path.StartsWith($SqDir, [System.StringComparison]::OrdinalIgnoreCase)) { return $true } } catch { }
    }
    return $false
}
$sqSeen = $false
$startTicks = [Environment]::TickCount
$lastSqCheck = 0

while ($true) {
    # shut down when StrategyQuant closes (checked every ~5 s)
    if (([Environment]::TickCount - $lastSqCheck) -gt 5000) {
        $lastSqCheck = [Environment]::TickCount
        if (Test-SqRunning) { $sqSeen = $true }
        elseif ($sqSeen) { break }
        elseif (([Environment]::TickCount - $startTicks) -gt 120000) { $sqSeen = $true }
    }
    if (-not $listener.Pending()) { Start-Sleep -Milliseconds 400; continue }

    $client = $null
    try {
        $client = $listener.AcceptTcpClient()
        $stream = $client.GetStream()
        $stream.ReadTimeout = 8000

        # read headers up to CRLFCRLF
        $hb = New-Object System.Collections.Generic.List[byte]
        while ($true) {
            $b = $stream.ReadByte()
            if ($b -lt 0) { break }
            $hb.Add([byte]$b)
            $n = $hb.Count
            if ($n -ge 4 -and $hb[$n-4] -eq 13 -and $hb[$n-3] -eq 10 -and $hb[$n-2] -eq 13 -and $hb[$n-1] -eq 10) { break }
        }
        $headerText = [System.Text.Encoding]::ASCII.GetString($hb.ToArray())
        if (-not $headerText) { $client.Close(); continue }

        $lines = $headerText -split "`r`n"
        $reqParts = $lines[0] -split ' '
        $method = $reqParts[0]
        $rawUrl = $reqParts[1]
        $path = $rawUrl; $query = ''
        if ($rawUrl -and $rawUrl.Contains('?')) { $path, $query = $rawUrl -split '\?', 2 }

        # body by Content-Length
        $contentLength = 0
        foreach ($ln in $lines) { if ($ln -match '(?i)^Content-Length:\s*(\d+)') { $contentLength = [int]$Matches[1]; break } }
        $body = ''
        if ($contentLength -gt 0) {
            $buf = New-Object byte[] $contentLength
            $read = 0
            while ($read -lt $contentLength) {
                $r = $stream.Read($buf, $read, $contentLength - $read)
                if ($r -le 0) { break }
                $read += $r
            }
            $body = [System.Text.Encoding]::UTF8.GetString($buf, 0, $read)
        }

        # ── routing ───────────────────────────────────────────────────────
        if ($method -eq 'OPTIONS') {
            Send-Response $stream 204 'No Content' ''
        }
        elseif ($path -eq '/ping') {
            Send-Json $stream 200 @{ ok = $true; service = 'runcompare-storage-ps' }
        }
        elseif ($path -eq '/load') {
            $fn = Get-QueryParam $query 'fileName'
            $hp = History-Path $fn
            if (-not $hp -or -not (Test-Path -LiteralPath $hp)) {
                Send-Json $stream 200 @{ history = @(); resolved = $hp }
            } else {
                try {
                    $data = Get-Content -LiteralPath $hp -Raw -Encoding UTF8 | ConvertFrom-Json
                    Send-Json $stream 200 @{ history = @($data.history); resolved = $hp }
                } catch {
                    Send-Json $stream 200 @{ history = @(); resolved = $hp; error = "$_" }
                }
            }
        }
        elseif ($path -eq '/save' -and $method -eq 'POST') {
            $fn = Get-QueryParam $query 'fileName'
            $hp = History-Path $fn
            if (-not $hp) {
                Send-Json $stream 400 @{ error = "invalid/empty fileName" }
            } else {
                try {
                    $parsed = $body | ConvertFrom-Json
                    if ($null -eq $parsed.history) {
                        Send-Json $stream 400 @{ error = 'expected {history: [...]}' }
                    } else {
                        $history = @($parsed.history)
                        Save-History $hp (Safe-Name $fn) $history
                        Send-Json $stream 200 @{ ok = $true; resolved = $hp; count = $history.Count }
                    }
                } catch {
                    Send-Json $stream 400 @{ error = "bad json: $_" }
                }
            }
        }
        else {
            Send-Json $stream 404 @{ error = 'not found' }
        }
    } catch {
        # swallow per-connection errors; keep serving
    } finally {
        if ($client) { $client.Close() }
    }
}
try { $listener.Stop() } catch { }
