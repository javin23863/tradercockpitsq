RunCompare - plugin + history backend
======================================

Backtest history viewer for SQ AlgoWizard. The plugin (index.html) runs in a
sandboxed iframe inside SQ Builder. Run history is saved by a small local
backend (server.ps1) that keeps one file per strategy in this plugin's own
"history" folder.

  * NO Python required - the backend runs on built-in Windows PowerShell.
  * NO configuration - nothing to set up. It just works.


How history is stored
---------------------
Run history is keyed by STRATEGY NAME and stored in:

    ...\RunCompare\history\<StrategyName>.runs.txt

Why by name (and not next to the .sqx file): StrategyQuant's plugin API only
tells a plugin the strategy NAME - never the file path - so name-keyed storage
is the only approach that works no matter where you keep your .sqx files.
Zero setup, and it never fails to find the right place.

Note: two different strategies that share the exact same name will share one
history. If you keep same-named strategies, give them distinct names.


Files (on deploy)
-----------------
<SQ install>\user\
  |- start-sq.bat                        one-click launcher (this is all you click)
  \- extend\ResultsPlugins\RunCompare\
       |- index.html                     plugin frontend (loaded by SQ)
       |- server.ps1                     PowerShell backend (localhost:8090)
       |- history\                       auto-created; your saved run histories
       \- README.txt


Setup (about a minute)
----------------------
1. Unzip this file.
2. Copy the "RunCompare" folder into your SQ install:
      C:\StrategyQuantX###\user\extend\ResultsPlugins\RunCompare\
3. Copy "start-sq.bat" into:
      C:\StrategyQuantX###\user\start-sq.bat
4. Start StrategyQuant by double-clicking start-sq.bat. That is the only file
   you ever click - it starts the backend in the background and opens SQ.

Nothing to configure. If the backend is not running, the plugin still works but
only in memory (history is lost on restart) - so always launch via start-sq.bat.


Endpoints (server.ps1)
----------------------
  GET  /ping                        health check
  GET  /load?fileName=MyStrategy    -> { history: [...] }
  POST /save?fileName=MyStrategy    body { history: [...] } -> saves history


Migration to a new SQ version
-----------------------------
Copy C:\StrategyQuantX###\user\ into the new install's user\ folder - this
brings start-sq.bat, the RunCompare folder, and your history\ in one shot.
