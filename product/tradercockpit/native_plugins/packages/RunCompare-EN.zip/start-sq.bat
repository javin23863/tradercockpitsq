@echo off
REM One-click launcher for StrategyQuant X + RunCompare backend (PowerShell - no Python).
REM
REM Universal across SQ versions - just copy this user/ folder into the new
REM SQ install. On first run from a new location, the desktop shortcut auto-updates.
REM
REM Paths it expects (all relative to this script):
REM   ..\StrategyQuantX.exe                            (SQ exe, one level up)
REM   .\extend\ResultsPlugins\RunCompare\server.ps1    (PowerShell backend)
REM   .\update-shortcut.ps1                            (shortcut self-update, optional)
REM
REM The backend runs on built-in Windows PowerShell - NO Python required.
REM It stays running in the background until reboot or manual kill.

setlocal
set "HERE=%~dp0"
set "RC=%HERE%extend\ResultsPlugins\RunCompare"
set "PORT=8090"
REM Resolve SQ install folder (one level up from user/) to absolute path - SQ exe needs
REM its own folder as working directory, otherwise it loads wrong libs and crashes silently.
for %%I in ("%HERE%..") do set "SQ_DIR=%%~fI"
set "SQ_EXE=%SQ_DIR%\StrategyQuantX.exe"

REM ----- Auto-update desktop shortcut on each run (optional) -----
if exist "%HERE%update-shortcut.ps1" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%HERE%update-shortcut.ps1"
)

REM ----- Start RunCompare backend if not already listening -----
REM Port appears BEFORE 'LISTENING' in netstat output, so regex must reflect that.
netstat -an | findstr /R /C:":%PORT% .*LISTENING" >nul 2>&1
if errorlevel 1 (
    if not exist "%RC%\server.ps1" (
        echo Backend script not found at %RC%\server.ps1
        pause
        exit /b 1
    )
    start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%RC%\server.ps1"
)

REM ----- Launch SQ -----
REM /D = explicit working directory for the spawned process. Without this SQ
REM inherits cmd's CWD (= user folder) and crashes when looking for its DLLs.
if exist "%SQ_EXE%" (
    start "" /D "%SQ_DIR%" "%SQ_EXE%"
    exit /b 0
) else (
    echo SQ exe not found at: %SQ_EXE%
    echo Make sure this user/ folder is inside SQ install folder ^(StrategyQuantX.exe one level up^).
    pause
    exit /b 1
)
